self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "65077f337a50be01080b85ff9285da28",
    "url": "assets/cover.jpg"
  },
  {
    "revision": "91482c69425ec2f370587c1539746c25",
    "url": "assets/css/_notes/dwsync.xml"
  },
  {
    "revision": "89485829c6768b149e947fcc2ef233f5",
    "url": "assets/css/global.css"
  },
  {
    "revision": "c62ecaa64d04f0bf954de309b96b4a07",
    "url": "assets/fonts/64.xml"
  },
  {
    "revision": "c02b6e22f036a777b178a48b0f72db66",
    "url": "assets/fonts/64_0.png"
  },
  {
    "revision": "e1d0acd8bd51eb065be807c4bdf5176b",
    "url": "assets/fonts/arcade.png"
  },
  {
    "revision": "4e1d59fe10df8faec75b3865ee2e77e7",
    "url": "assets/fonts/arcade.xml"
  },
  {
    "revision": "84dce2d7ff5273e36626cea86b28416e",
    "url": "assets/fonts/test.png"
  },
  {
    "revision": "072984206d2b3a2b52107220e6295fd2",
    "url": "assets/icons/icons-192.png"
  },
  {
    "revision": "7f0b84941169237c303e911a0219f8bd",
    "url": "assets/icons/icons-512.png"
  },
  {
    "revision": "a2bcb8df438116a7ac9a07282276e8d8",
    "url": "assets/images/arm.png"
  },
  {
    "revision": "de529cfbef61020ff119e00697691a51",
    "url": "assets/images/bg-level1new.png"
  },
  {
    "revision": "0825d2a64dd1f83c36b8e74a3be78cdb",
    "url": "assets/images/bg-level2new.png"
  },
  {
    "revision": "2ebbddcd8064487c2537ce66d4f5eaf8",
    "url": "assets/images/bg-level3.png"
  },
  {
    "revision": "08aa9e4bccb5dda8c5896c42bdaf014c",
    "url": "assets/images/blood.png"
  },
  {
    "revision": "c347cc9a5e9db11804b30174a6f736dc",
    "url": "assets/images/body.png"
  },
  {
    "revision": "c67ce9dff071b41d8eb9f2c9fd71c19f",
    "url": "assets/images/bodyparts.png"
  },
  {
    "revision": "c2ddca5363fcd2971afdd647bffa54f4",
    "url": "assets/images/bonus-broom.png"
  },
  {
    "revision": "1bd0b8807a8601d93744bea1a1d68ade",
    "url": "assets/images/bonus-fire.png"
  },
  {
    "revision": "cab1a3433e07137007588e9d03867917",
    "url": "assets/images/bonus-heart.png"
  },
  {
    "revision": "84f80e13dc7d78927db09a66dd945f73",
    "url": "assets/images/bonus-mask.png"
  },
  {
    "revision": "c902ac83c2ae2c9d456941652a58d58e",
    "url": "assets/images/bonus-milk.png"
  },
  {
    "revision": "f2a672915f244d1b57527091b1e78c93",
    "url": "assets/images/boss-base.png"
  },
  {
    "revision": "24f1aac671fc31d529f355f01bd3872f",
    "url": "assets/images/boss-top.png"
  },
  {
    "revision": "c06f4b28c149316dd8030e4765ee6085",
    "url": "assets/images/bossPump.png"
  },
  {
    "revision": "18b2592b636ac9844dde33c6662ac9c3",
    "url": "assets/images/bullet - Copia.png"
  },
  {
    "revision": "cd5ed63c7da9e2bf28e6f7a2de758bc8",
    "url": "assets/images/bullet.png"
  },
  {
    "revision": "5622e143cdcf6751e9a262057dbfa4e8",
    "url": "assets/images/cat.png"
  },
  {
    "revision": "624b56b73ba3832ebe44732868feffdb",
    "url": "assets/images/cloud1.png"
  },
  {
    "revision": "52f490fbdc96b4ba29e5355de22b5f68",
    "url": "assets/images/cloud2.png"
  },
  {
    "revision": "853a716ff6d259b95fe9bc9f88131051",
    "url": "assets/images/coffin.png"
  },
  {
    "revision": "944ed2fc5f5827a3aeab1cc60c8e5db6",
    "url": "assets/images/credits.png"
  },
  {
    "revision": "a5b71c864642baf284c62f19ab477ab1",
    "url": "assets/images/deluca.png"
  },
  {
    "revision": "70ca3b7c24f25c380cbdbe30b0d801cd",
    "url": "assets/images/enemy-bat.png"
  },
  {
    "revision": "238fd052533dc2e6a3747c2088800564",
    "url": "assets/images/enemy-dracula.png"
  },
  {
    "revision": "27a2acc404011b10a5934e027f6a2a91",
    "url": "assets/images/enemy-ghast.png"
  },
  {
    "revision": "589b988253d9186bd84e4971d93ef91d",
    "url": "assets/images/enemy-ghost.png"
  },
  {
    "revision": "1bbe897c2bcf2a1f55b4ac611f78a3a5",
    "url": "assets/images/enemy-pump.png"
  },
  {
    "revision": "3dbdd4838b7b0f26790ed2b27d363758",
    "url": "assets/images/enemy-witch.png"
  },
  {
    "revision": "093d5e74e506694ebd5609c8424c2f98",
    "url": "assets/images/enemy-wolf.png"
  },
  {
    "revision": "a278bd23db593851a70a2b3dbc2c601a",
    "url": "assets/images/enemyBullet.png"
  },
  {
    "revision": "831dc3ccb355e92dc8a59c8836f9df94",
    "url": "assets/images/energy-bar-mask.png"
  },
  {
    "revision": "62ebbc34a40213f384428a02e347925f",
    "url": "assets/images/energy-bar.png"
  },
  {
    "revision": "e926b0839c841c007162032b69e80e2b",
    "url": "assets/images/explosionParticles.json"
  },
  {
    "revision": "b6d9383ffef931e26eae8dadf9306e5c",
    "url": "assets/images/explosionParticles.png"
  },
  {
    "revision": "f80e48c37000668f3f55c6898430f4bc",
    "url": "assets/images/faces.png"
  },
  {
    "revision": "95bad10044bd483fdd67d06c6b7594f3",
    "url": "assets/images/fairlight-logo.png"
  },
  {
    "revision": "1b024b64a6686e6ab99420b41338a485",
    "url": "assets/images/fairlight-raster.png"
  },
  {
    "revision": "22deace71033768b46c3d4b53469d668",
    "url": "assets/images/fairlight-raster2.png"
  },
  {
    "revision": "ed2c7818ca8046c0318119efdbe9a808",
    "url": "assets/images/game-over-bg.png"
  },
  {
    "revision": "e36d1ec3898d2fa55533c0e5835f8466",
    "url": "assets/images/gameover/block.png"
  },
  {
    "revision": "e9d74707a3b6d752219c5c3d21b0bb1c",
    "url": "assets/images/gameover/end.png"
  },
  {
    "revision": "cdc6de18e2d1eba26d61d19dd61c37c4",
    "url": "assets/images/gameover/rub.png"
  },
  {
    "revision": "d37a73d9e6815cd9159f7b22f21d1138",
    "url": "assets/images/hallaweenNew.png"
  },
  {
    "revision": "5bf9546903e97f0778577de7e77c5b8c",
    "url": "assets/images/heart.png"
  },
  {
    "revision": "defb6ed348096f0129cd4d4e62966d72",
    "url": "assets/images/how-to.png"
  },
  {
    "revision": "e73f0e9edd0fc44d71def6f02324554e",
    "url": "assets/images/levels.png"
  },
  {
    "revision": "6524d3b3f095fc0c65bb4d4a4d3a867f",
    "url": "assets/images/me.png"
  },
  {
    "revision": "8e240a8507243a4f9c004bf3c91e1400",
    "url": "assets/images/muzzleflash3.png"
  },
  {
    "revision": "be162e4a05213f198facc3d405ad4bff",
    "url": "assets/images/ouas-logo.png"
  },
  {
    "revision": "9ef1c834b6fc76715038ea7d7ae54f5b",
    "url": "assets/images/ouas.png"
  },
  {
    "revision": "ca0b0f68dc82d1a55621399ea951fb23",
    "url": "assets/images/pumpkin.png"
  },
  {
    "revision": "c44bbaf68f8f0e499e1e71c0fd1e791b",
    "url": "assets/images/random-end.png"
  },
  {
    "revision": "629a75fd52f2dc6ac84d80b347402d29",
    "url": "assets/images/santa.png"
  },
  {
    "revision": "b1823c9e8ea7cffd6c524f33a898fc14",
    "url": "assets/images/scanlines.png"
  },
  {
    "revision": "40c5cb016bb1cebb21f4a68bd8f1eb99",
    "url": "assets/images/share.png"
  },
  {
    "revision": "27c5465b5deb9f928678e648c545c1c1",
    "url": "assets/images/skynew.png"
  },
  {
    "revision": "8fc96fc7bc1f848d58060817cab71e70",
    "url": "assets/images/smoke-puff.png"
  },
  {
    "revision": "756adaf2de298928d681e5d57081295e",
    "url": "assets/images/smoke0.png"
  },
  {
    "revision": "431b99d2aa2576def6aa2b940c6fff1f",
    "url": "assets/images/spark.png"
  },
  {
    "revision": "7eb6934ba1a8336bf99899fdec2714ed",
    "url": "assets/images/thelucasart.png"
  },
  {
    "revision": "19f74d48afb822e0274c37ca929f6439",
    "url": "assets/js/VirtualJoystickPlugin.min.js"
  },
  {
    "revision": "bc7a70b3f280c7445e2437338cce9144",
    "url": "assets/js/firebase.js"
  },
  {
    "revision": "2edc942c0bd2476be8967a9f788d9e26",
    "url": "assets/js/jquery.js"
  },
  {
    "revision": "39e681e9a66a3dd1628cff3258b662d8",
    "url": "assets/js/rexJoystick.js"
  },
  {
    "revision": "23dd87c388e80e46a18dd9938619454c",
    "url": "assets/js/rexgestures.js"
  },
  {
    "revision": "e9e9f2003cb2cd6791388f5f605864ab",
    "url": "assets/js/webfonts.js"
  },
  {
    "revision": "194577a7e20bdcc7afbb718f502c134c",
    "url": "assets/map/.DS_Store"
  },
  {
    "revision": "cdccdc2a99801b956ed0d26c5e00b6e2",
    "url": "assets/map/level-1.json"
  },
  {
    "revision": "8822c22fe1bd35099afde1a2b85dc02f",
    "url": "assets/map/tilemap.png"
  },
  {
    "revision": "4f35f8174cfb49323b48ac5c5acc8482",
    "url": "assets/map/tilemap.psd"
  },
  {
    "revision": "ce8e4c3b58135282fa6c5b4d1c1ae84c",
    "url": "assets/skins/arcade-joystick.json"
  },
  {
    "revision": "6de14b979f318bf7596b14572844b977",
    "url": "assets/skins/arcade-joystick.png"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "assets/skins/debug.log"
  },
  {
    "revision": "48cc2fe4cf7c2f17d97246d1d2c42a2e",
    "url": "assets/skins/dpad.json"
  },
  {
    "revision": "e29022f7a3b696997214e6b571dd3e44",
    "url": "assets/skins/dpad.png"
  },
  {
    "revision": "f08377947f286a6794b17d57952fd8ea",
    "url": "assets/skins/generic-joystick.json"
  },
  {
    "revision": "f191fc52284c7bf67d582adcab642e2e",
    "url": "assets/skins/generic-joystick.png"
  },
  {
    "revision": "7d378f9ecd45eb3b0690fe8a812dc33f",
    "url": "assets/skins/spritesheet.json"
  },
  {
    "revision": "4e2bf44a180c3694407bcd850b9c4311",
    "url": "assets/skins/spritesheet.png"
  },
  {
    "revision": "e1d39fd7e1d253d3ec395a217f286207",
    "url": "assets/sounds/alarm.m4a"
  },
  {
    "revision": "0db7f9f1aab438a289cc4cd6baff3c2a",
    "url": "assets/sounds/alarm.ogg"
  },
  {
    "revision": "731b68e83cb9ec0977d371b8c440da69",
    "url": "assets/sounds/allauin.m4a"
  },
  {
    "revision": "4b5b6b7cb75df230f78f4aa48411828b",
    "url": "assets/sounds/allauin.ogg"
  },
  {
    "revision": "2d91be9272c15cea0e3c98aae296a2cb",
    "url": "assets/sounds/boss.m4a"
  },
  {
    "revision": "955113df41ccb75a96e7bee3ffa88fe5",
    "url": "assets/sounds/boss.ogg"
  },
  {
    "revision": "296dd4bafd76b661bf9f27a3944378df",
    "url": "assets/sounds/fairlight.m4a"
  },
  {
    "revision": "e12feb2b62f08a2be04c260395071627",
    "url": "assets/sounds/fairlight.ogg"
  },
  {
    "revision": "7b9df3d35670a28900ff502a8281019d",
    "url": "assets/sounds/gameover.m4a"
  },
  {
    "revision": "78326471be100785d6b614077f6193d9",
    "url": "assets/sounds/gameover.ogg"
  },
  {
    "revision": "a63ce0cfa79500945ab3dd2ea2919d71",
    "url": "assets/sounds/halloween.m4a"
  },
  {
    "revision": "bcdbb003d716e085ba362989084d393b",
    "url": "assets/sounds/halloween.ogg"
  },
  {
    "revision": "c763061b7e279d065caa96d154a80a92",
    "url": "assets/sounds/music1.m4a"
  },
  {
    "revision": "236a24851854807022bfceb01aeaa9e4",
    "url": "assets/sounds/music1.ogg"
  },
  {
    "revision": "24f9da129605fbeaa1989d8b3c1f21eb",
    "url": "assets/sounds/music2.m4a"
  },
  {
    "revision": "5d028f70120f820f1aa672b3c980028e",
    "url": "assets/sounds/music2.ogg"
  },
  {
    "revision": "f5caf3e4a3746cdf07bf3e37bc26bb51",
    "url": "assets/sounds/sfx.json"
  },
  {
    "revision": "16cced5dffde962b1b72c76c72aaa4e5",
    "url": "assets/sounds/sfx.m4a"
  },
  {
    "revision": "fe628edc8351fd41bb308af369ef97a9",
    "url": "assets/sounds/sfx.ogg"
  },
  {
    "revision": "d91355f3b69ff6bc3d54c9a1f2eff317",
    "url": "assets/sounds/thunder.m4a"
  },
  {
    "revision": "2c2763d515dabb228f0f2e620d590048",
    "url": "assets/sounds/thunder.ogg"
  },
  {
    "revision": "fc420e70a45d19441848342b1eb040cf",
    "url": "assets/sounds/win.m4a"
  },
  {
    "revision": "0a25120ff56606aba245a39d6510be16",
    "url": "assets/sounds/win.ogg"
  },
  {
    "revision": "87554cee99a05cc3dca03b6ef45704ad",
    "url": "favicon.ico"
  },
  {
    "revision": "76f11e365fb73bd03cacc47b94ad855e",
    "url": "index.html"
  },
  {
    "revision": "c2aac27804608f172107",
    "url": "main.6e9a65032a6d7d88964b.bundle.js"
  },
  {
    "revision": "d78d3f5dbe9de5cd7fb8bfa3f6a3fa2d",
    "url": "manifest.json"
  },
  {
    "revision": "301d14d11cfe6dcc0f2d134aa03815d0",
    "url": "sw.js"
  },
  {
    "revision": "c1d316a9f7f5b1b1ee80",
    "url": "vendors.de083a99386772842629.bundle.js"
  }
]);