importScripts("precache-manifest.a976443b0ac987be3c447fbb73dfcbe1.js", "https://storage.googleapis.com/workbox-cdn/releases/4.3.1/workbox-sw.js");

workbox.precaching.precacheAndRoute(__precacheManifest);

